plugin.video.nbcsnliveextra
======================

KODI plugin NBC Sports Live Extra

This plugin was built to watch** live and archive video of NBC Sports events 


Thread: http://forum.kodi.tv/showthread.php?tid=207159

** Most streams require a valid Cable / Satellite provider account to view
